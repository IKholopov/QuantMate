#pragma once

#include "Scene.h"

#define GC_MOUSECLICK

struct ControllerCommand {
	short Command;
	short SceneId;
	short ControllerId;
};

class IGameController {
	virtual ControllerCommand OnMouseClick() = 0;
	void SetScene(CScene* scene);
private:
	CScene* scene;
};