#pragma once

#include "Scene.h"
#include "GameController.h"
#include "GameResources.h"

class IFactory {
public:
	virtual CScene* GetMainScene(CResourceManager& manager) = 0;
	virtual IGameController* GetMainController() = 0;
	virtual IGameResources* GetResources() = 0;

	virtual CScene* GetScene(int id, CResourceManager& manager) = 0;
	virtual IGameController* GetController(int id) = 0;
};