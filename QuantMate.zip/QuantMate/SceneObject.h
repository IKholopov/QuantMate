#pragma once

#include <Windows.h>
#include "ResourceManager.h"

class ISceneObject {
public:
	virtual void Render(HDC hdc) = 0;
	virtual void OnTimerTick() = 0;
	virtual void FetchResources(CResourceManager& manager) = 0;
};