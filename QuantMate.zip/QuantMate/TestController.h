#pragma once

#include "GameController.h"

class CTestController: public IGameController {
public:
	// Inherited via GameController
	ControllerCommand OnMouseClick() override;
};