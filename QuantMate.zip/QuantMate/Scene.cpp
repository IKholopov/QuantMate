#include "Scene.h"

CScene::CScene()
{
}

CScene::~CScene()
{
}

void CScene::Render(HDC hdc)
{
	for( auto obj = objects.begin(); obj != objects.end(); ++obj ) {
		(*obj).second->Render(hdc);
	}
}

void CScene::OnTimerTick()
{
	for( auto obj = objects.begin(); obj != objects.end(); ++obj ) {
		(*obj).second->OnTimerTick();
	}
}
