#pragma once

#include "Scene.h"

class CTestScene: public CScene {
public:
	CTestScene(CResourceManager& manager);
	~CTestScene();
};