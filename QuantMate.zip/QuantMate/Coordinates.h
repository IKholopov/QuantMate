#pragma once

struct Coordinates {
	Coordinates();
	Coordinates(int x, int y);

	int X;
	int Y;
};