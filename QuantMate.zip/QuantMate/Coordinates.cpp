#include "Coordinates.h"

Coordinates::Coordinates()
{
	this->X = 0;
	this->Y = 0;
}

Coordinates::Coordinates(int x, int y)
{
	this->X = x;
	this->Y = y;
}
