#pragma once

#include "SceneObject.h"
#include "Coordinates.h"

#define BOARD_BACKGROUND_COLOR RGB(237, 237, 237)
#define BOARD_WHITE_COLOR RGB(255, 255, 255)
#define BOARD_BLACK_COLOR RGB(0, 0, 0)
#define BOARD_BORDER_OFFSET 20


class CBoard: public ISceneObject {
public:
	CBoard(Coordinates position, int width);

	RECT GetBox(const Coordinates& position) const;
	// Inherited via ISceneObject
	void Render(HDC hdc) override;
	void OnTimerTick() override;
	void FetchResources(CResourceManager & manager) override;
private:
	RECT boardRect;
	int startX;
	int startY;
	int squareWidth;
	int squareRest;
};