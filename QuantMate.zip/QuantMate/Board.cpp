#include "Board.h"

CBoard::CBoard(Coordinates position, int width) {
	boardRect.left = position.X;
	boardRect.top = position.Y;
	boardRect.right = position.X + width;
	boardRect.bottom = position.Y + width;
	startX = boardRect.left + BOARD_BORDER_OFFSET;
	startY = boardRect.top + BOARD_BORDER_OFFSET;
	squareWidth = (boardRect.right - boardRect.left - 2 * BOARD_BORDER_OFFSET) / 8;
	squareRest = (boardRect.right - boardRect.left - 2 * BOARD_BORDER_OFFSET) % 8;
}

RECT CBoard::GetBox(const Coordinates& position) const
{
	RECT rect;
	rect.left = startX + squareWidth * position.X + (squareRest >= position.X ? position.X : squareRest);
	rect.right = startX + squareWidth * (position.X + 1) + (squareRest > position.X ? position.X + 1 : squareRest);
	rect.top = startY + squareWidth * position.Y + (squareRest >= position.Y ? position.Y : squareRest);
	rect.bottom = startY + squareWidth * (position.Y + 1) + (squareRest > position.Y ? position.Y + 1 : squareRest);
	return rect;
}

void CBoard::Render(HDC hdc)
{
	SetDCBrushColor(hdc, BOARD_BACKGROUND_COLOR);
	FillRect(hdc, &boardRect, (HBRUSH)GetStockObject(DC_BRUSH));
	RECT squareRect;
	int yRest = squareRest;
	int yMoved = 0;
	for( int i = 0; i < 8; ++i ) {
		int xRest = squareRest;
		int xMoved = 0;
		for( int j = 0; j < 8; ++j ) {
			squareRect.left = startX + j * squareWidth + xMoved;
			squareRect.right = startX + (j + 1) * squareWidth + xMoved;
			if( xRest ) {
				xRest -= 1;
				squareRect.right += 1;
				xMoved += 1;
			}
			squareRect.top = startY + i * squareWidth + yMoved;
			squareRect.bottom = startY + (i + 1) * squareWidth + yMoved;
			if( yRest ) {
				squareRect.bottom += 1;
			}
			SetDCBrushColor(hdc, (i + j) % 2 ? BOARD_BLACK_COLOR : BOARD_WHITE_COLOR);
			FillRect(hdc, &squareRect, (HBRUSH)GetStockObject(DC_BRUSH));
		}
		if( yRest ) {
			yRest -= 1;
			yMoved += 1;
		}
	}
}

void CBoard::OnTimerTick()
{
}

void CBoard::FetchResources(CResourceManager & manager)
{
}
