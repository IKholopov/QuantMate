#include "ChessFigure.h"

#include <assert.h>
#include "BitmapResource.h"

CChessFigure::CChessFigure(Figure figure, FigureColor color, Coordinates position, float probability)
{
	this->figure = figure;
	this->color = color;
	assert(position.X >= 0 && position.X < 8);
	assert(position.Y >= 0 && position.Y < 8);
	this->position = position;
	this->probability = probability;
}

void CChessFigure::Render(HDC hdc)
{
	auto graphics = Gdiplus::Graphics::FromHDC(hdc);
	Gdiplus::RectF rect;
	sprite->GetBounds(rect);
	Gdiplus::GraphicsPath pathRed;
	Gdiplus::GraphicsPath pathBlue;
	pathBlue.AddArc(rect, -90, 360);
	pathRed.AddArc(rect, -90, 360 * probability);
	Gdiplus::Pen penRed(Gdiplus::Color::Red, FIGURE_CHART_THICKNESS);
	Gdiplus::Pen penBlue(Gdiplus::Color::Blue, FIGURE_CHART_THICKNESS);
	graphics->DrawPath(&penBlue, &pathBlue);
	graphics->DrawPath(&penRed, &pathRed);
	sprite->Draw(hdc, position.X, position.Y);
}

void CChessFigure::OnTimerTick()
{
}

void CChessFigure::FetchResources(CResourceManager & manager)
{
	IResource* resource;
	switch( this->figure ) {
	case PAWN:
		if( color == WHITE ) {
			resource = manager.GetResource(CQuantMateResources::PAWN_WHITE);
		} else {
			resource = manager.GetResource(CQuantMateResources::PAWN_BLACK);
		}
		break;
	case ROOK:
		if( color == WHITE ) {
			resource = manager.GetResource(CQuantMateResources::ROOK_WHITE);
		} else {
			resource = manager.GetResource(CQuantMateResources::ROOK_BLACK);
		}
		break;
	case BISHOP:
		if( color == WHITE ) {
			resource = manager.GetResource(CQuantMateResources::BISHOP_WHITE);
		} else {
			resource = manager.GetResource(CQuantMateResources::BISHOP_BLACK);
		}
		break;
	case KNIGHT:
		if( color == WHITE ) {
			resource = manager.GetResource(CQuantMateResources::KNIGHT_WHITE);
		} else {
			resource = manager.GetResource(CQuantMateResources::KNIGHT_BLACK);
		}
		break;
	case QUEEN:
		if( color == WHITE ) {
			resource = manager.GetResource(CQuantMateResources::QUEEN_WHITE);
		} else {
			resource = manager.GetResource(CQuantMateResources::QUEEN_BLACK);
		}
		break;
	case KING:
		if( color == WHITE ) {
			resource = manager.GetResource(CQuantMateResources::KING_WHITE);
		} else {
			resource = manager.GetResource(CQuantMateResources::KING_BLACK);
		}
		break;
	default:
		throw std::logic_error("Invalid figure\n");
		return;
	}
	sprite = std::unique_ptr<CSprite>(new CSprite(static_cast<CBitmapResource*>(resource)->GetBitmap()));	
}

