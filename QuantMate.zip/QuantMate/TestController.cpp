#include "TestController.h"

ControllerCommand CTestController::OnMouseClick()
{
	return ControllerCommand();
}
