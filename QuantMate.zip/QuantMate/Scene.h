#pragma once

#include <vector>

#include "SceneObject.h"

class CScene {
public:
	CScene();
	virtual ~CScene();
	void Render(HDC hdc);
	void OnTimerTick();
protected:
	std::map<int, std::unique_ptr<ISceneObject>> objects;
};