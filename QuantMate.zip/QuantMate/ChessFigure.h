#pragma once

#include <vector>
#include "SceneObject.h"
#include "Sprite.h"
#include "Coordinates.h"
#include "QuantMateResources.h"

#define FIGURE_CHART_THICKNESS 5

class CChessFigure : public ISceneObject {
public:
	enum Figure {
		PAWN, ROOK, BISHOP, KNIGHT, QUEEN, KING
	};
	enum FigureColor {
		WHITE, BLACK
	};
	CChessFigure(Figure figure, FigureColor color, Coordinates position, float probability=1.0f);
	// Inherited via ISceneObject
	void Render(HDC hdc) override;
	void OnTimerTick() override;
	void FetchResources(CResourceManager & manager) override;
private:
	Figure figure;
	FigureColor color;
	std::unique_ptr<CSprite> sprite;
	Coordinates position;
	float probability;
};