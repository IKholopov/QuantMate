#include "TestScene.h"

#include "ChessFigure.h"
#include "Board.h"

CTestScene::CTestScene(CResourceManager& manager)
{
	auto pawn = std::unique_ptr<CChessFigure>(new CChessFigure(CChessFigure::BISHOP, CChessFigure::WHITE, Coordinates(0, 0), 0.66));
	pawn->FetchResources(manager);
	objects.insert(std::make_pair(1, std::move(pawn)));
	auto board = std::unique_ptr<CBoard>(new CBoard(Coordinates(30, 20), 640));
	board->FetchResources(manager);
	objects.insert(std::make_pair(-1, std::move(board)));
}

CTestScene::~CTestScene()
{
}
