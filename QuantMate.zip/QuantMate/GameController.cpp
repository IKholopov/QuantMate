#include "GameController.h"

void IGameController::SetScene(CScene * scene)
{
	this->scene = scene;
}
